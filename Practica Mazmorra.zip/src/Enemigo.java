public class Enemigo {
    //Atributos privados
    private String nombreEnemigo;
    private int vidaActualEnemigo;
    private int vidaMaximaEnemigo;
    private int danoBaseEnemigo;

    //Constructores
    public Enemigo(String nombreEnemigo, int vidaMaximaEnemigo, int danoBaseEnemigo){
        this.nombreEnemigo = nombreEnemigo;
        //La vida actual la cambio por la vida máxima.
        this.vidaActualEnemigo = vidaMaximaEnemigo;
        this.vidaMaximaEnemigo = vidaMaximaEnemigo;
        this.danoBaseEnemigo = danoBaseEnemigo;
    }

    //Métodos
    public int recibirDanoEnemigo(Aventurero aventurero){
        int recibirDano = 0;
        if (vidaActualEnemigo >= 0) {
        recibirDano = vidaActualEnemigo - aventurero.atacarAventurero();
        }
        return recibirDano;
    }
    public boolean estaDerrotado() {
        boolean estaDerrotado = false;
        if (vidaActualEnemigo <= 0) {
            estaDerrotado = true;
        }
        return estaDerrotado;
    }
    public int atacarEnemigo() {
        int atacarEnemigo = danoBaseEnemigo;
        return atacarEnemigo;
    }
}
