public class Aventurero {
    //Atributos
    private String nombreAventurero;
    private int vidaActualAventurero;
    private int vidaMaximaAventurero;
    private int danoBaseAventurero;
    private int cantidadPocionesAventurero;

    //Constante
    private static final int curacion = 20;

    //Getter


    public Aventurero(String nombreAventurero, int vidaMaximaAventurero, int danoBaseAventurero, int cantidadPocionesAventurero){
        this.nombreAventurero = nombreAventurero;
        //La vida actual la cambio por la vida máxima.
        this.vidaActualAventurero = vidaMaximaAventurero;
        this.vidaMaximaAventurero = vidaMaximaAventurero;
        this.danoBaseAventurero = danoBaseAventurero;
        this.cantidadPocionesAventurero = cantidadPocionesAventurero;
    }
    public int atacarAventurero() {
        int atacarAventurero = danoBaseAventurero;
        return atacarAventurero;
    }

    public void beberPocion() {
        if (cantidadPocionesAventurero > 0) {
        cantidadPocionesAventurero--;
        vidaActualAventurero = vidaActualAventurero + curacion;
        }
    }
    public int recibirDanoAventurero(Enemigo enemigo){
        int recibirDanoAventurero = 0;
        if (vidaActualAventurero >= 0) {
        recibirDanoAventurero = vidaActualAventurero - enemigo.atacarEnemigo();
        }
        return recibirDanoAventurero;
    }
    public boolean estaCaido() {
        boolean estaCaido = false;
        if (vidaActualAventurero <= 0) {
            estaCaido = true;
        }
        return estaCaido;
    }
}
