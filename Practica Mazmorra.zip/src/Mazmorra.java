import java.util.Scanner;
public class Mazmorra {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        //Enemigo
        System.out.print("Nombre del enemigo: ");
        String nombreEnemigo = scan.nextLine();
        System.out.print("Vida máxima del enemigo: ");
        int vidaMaximaEnemigo = scan.nextInt();
        System.out.print("Daño base del enemigo: ");
        int danoBaseEnemigo = scan.nextInt();


        Enemigo enemigo = new Enemigo(nombreEnemigo, vidaMaximaEnemigo, danoBaseEnemigo);
    }
}
